from __future__ import annotations

import re
from collections import Counter
from typing import Any, Dict, Iterable, List, Sequence, Tuple


class ReviewInsightEngine:
    """
    Sprint70-1 Review Insight Engine

    쿠팡 리뷰와 TikTok/Douyin 댓글을 함께 분석하는 API 없는 규칙 기반 엔진입니다.

    기존 호환:
        analyze(reviews=..., product_name=...)

    Sprint70 확장:
        analyze(
            reviews=...,
            social_comments=...,
            product_name=...,
        )
    """

    VERSION = "review-insight-engine-70-1"

    TEXT_KEYS = (
        "content",
        "review",
        "text",
        "body",
        "comment",
        "review_content",
        "headline",
        "title",
        "description",
    )

    POSITIVE_WORDS = (
        "좋아",
        "좋습니다",
        "만족",
        "편해",
        "편리",
        "추천",
        "잘 쓰",
        "유용",
        "깔끔",
        "튼튼",
        "예뻐",
        "이뻐",
        "간편",
        "쉽게",
        "빠르",
        "효과",
        "재구매",
        "최고",
        "괜찮",
    )

    NEGATIVE_WORDS = (
        "불편",
        "아쉽",
        "별로",
        "안 좋",
        "약해",
        "떨어",
        "고장",
        "비싸",
        "어렵",
        "번거",
        "작아",
        "커서",
        "무거",
        "냄새",
        "소음",
        "실망",
        "반품",
        "후회",
        "문제",
    )

    PURCHASE_WORDS = (
        "구매",
        "주문",
        "사고 싶",
        "어디서 사",
        "가격",
        "얼마",
        "링크",
        "구매방법",
        "사는법",
        "쿠팡",
        "제품명",
        "정보",
        "자동",
    )

    QUESTION_WORDS = (
        "?",
        "어디",
        "어떻게",
        "얼마",
        "무슨",
        "뭔가",
        "인가요",
        "되나요",
        "있나요",
        "링크",
        "구매방법",
    )

    PAIN_RULES = {
        "사용이 불편하거나 번거롭다": (
            "불편",
            "번거",
            "귀찮",
            "힘들",
            "어렵",
        ),
        "내구성이나 고정력이 걱정된다": (
            "떨어",
            "약해",
            "부서",
            "고장",
            "흔들",
            "튼튼하지",
        ),
        "크기나 공간 활용이 아쉽다": (
            "작아",
            "너무 커",
            "자리 차지",
            "공간",
            "좁",
            "보관",
        ),
        "가격이 부담스럽다": (
            "비싸",
            "가격",
            "가성비",
            "돈 아까",
        ),
        "품질이나 효과가 기대보다 부족하다": (
            "효과 없",
            "별로",
            "실망",
            "안 되",
            "제대로",
            "품질",
        ),
        "소음·냄새·위생 문제가 걱정된다": (
            "소음",
            "시끄",
            "냄새",
            "위생",
            "곰팡",
            "오염",
        ),
    }

    BENEFIT_RULES = {
        "사용이 간편하고 편리하다": (
            "편해",
            "편리",
            "간편",
            "쉽게",
            "자동",
        ),
        "시간과 수고를 줄일 수 있다": (
            "빠르",
            "시간",
            "귀찮지",
            "한번에",
            "손쉽",
        ),
        "정리와 공간 활용에 도움이 된다": (
            "깔끔",
            "정리",
            "공간 활용",
            "보관",
            "자리 차지하지",
        ),
        "성능과 효과가 만족스럽다": (
            "효과",
            "잘 되",
            "만족",
            "성능",
            "유용",
        ),
        "튼튼하고 안정적으로 사용할 수 있다": (
            "튼튼",
            "고정",
            "안정",
            "잘 떨어지지",
            "내구",
        ),
        "디자인과 외관이 만족스럽다": (
            "예뻐",
            "이뻐",
            "디자인",
            "고급",
            "보기 좋",
        ),
    }

    PERSONA_RULES = {
        "간편한 사용을 원하는 사람": (
            "간편",
            "쉽게",
            "자동",
            "편리",
        ),
        "시간을 절약하고 싶은 사람": (
            "시간",
            "빠르",
            "한번에",
            "귀찮",
        ),
        "정리와 공간 활용을 중시하는 사람": (
            "정리",
            "깔끔",
            "공간",
            "보관",
        ),
        "가성비를 중요하게 생각하는 사람": (
            "가격",
            "가성비",
            "비싸",
            "저렴",
        ),
        "아이 또는 가족과 함께 사용하는 사람": (
            "아이",
            "아기",
            "부모님",
            "가족",
            "어르신",
        ),
        "제품 구매 전 실제 후기를 확인하는 사람": (
            "후기",
            "써보",
            "만족",
            "추천",
            "구매",
        ),
    }

    STOP_WORDS = {
        "그냥",
        "정말",
        "진짜",
        "너무",
        "아주",
        "약간",
        "제품",
        "상품",
        "사용",
        "구매",
        "주문",
        "배송",
        "리뷰",
        "댓글",
        "영상",
        "쿠팡",
        "합니다",
        "있어요",
        "없어요",
        "같아요",
        "좋아요",
        "좋습니다",
        "자동",
    }

    def analyze(
        self,
        reviews: Any = None,
        product_name: str = "",
        social_comments: Any = None,
    ) -> Dict[str, Any]:
        review_texts = self._normalize_texts(reviews)
        social_texts = self._normalize_texts(social_comments)

        review_texts = self._deduplicate(review_texts)
        social_texts = self._deduplicate(social_texts)

        combined = self._deduplicate(review_texts + social_texts)

        if not combined:
            return self._empty_result(product_name)

        pain_points = self._score_rules(combined, self.PAIN_RULES)
        benefits = self._score_rules(combined, self.BENEFIT_RULES)
        personas = self._score_rules(combined, self.PERSONA_RULES)

        best_pain = self._best_label(
            pain_points,
            "사용 전 불편함이나 구매 고민이 있다",
        )
        best_benefit = self._best_label(
            benefits,
            "사용이 간편하고 생활을 편리하게 만든다",
        )
        best_persona = self._best_label(
            personas,
            "간편하고 실용적인 제품을 찾는 사람",
        )

        purchase_intent = self._purchase_intent(combined)
        sentiment = self._sentiment(combined)
        questions = self._extract_questions(combined)
        keywords = self._common_keywords(combined)
        evidence = self._evidence_samples(
            review_texts=review_texts,
            social_texts=social_texts,
        )

        best_buy_reason = self._build_buy_reason(
            best_pain=best_pain,
            best_benefit=best_benefit,
            purchase_intent=purchase_intent,
        )

        hooks = self._build_hooks(
            product_name=product_name,
            best_pain=best_pain,
            best_benefit=best_benefit,
            purchase_intent=purchase_intent,
            questions=questions,
        )
        ctas = self._build_ctas(product_name, purchase_intent)

        return {
            "ok": True,
            "version": self.VERSION,
            "product_name": product_name,
            "review_count": len(review_texts),
            "social_comment_count": len(social_texts),
            "total_text_count": len(combined),
            "pain_points": pain_points[:5],
            "benefits": benefits[:5],
            "buy_reasons": [
                {
                    "label": best_buy_reason,
                    "score": purchase_intent["score"],
                    "count": purchase_intent["matched_count"],
                }
            ],
            "personas": personas[:5],
            "common_keywords": keywords[:10],
            "best_pain_point": best_pain,
            "best_benefit": best_benefit,
            "best_buy_reason": best_buy_reason,
            "purchase_reason": best_buy_reason,
            "best_persona": best_persona,
            "target_customer": best_persona,
            "objection": best_pain,
            "purchase_intent": purchase_intent,
            "sentiment": sentiment,
            "question_signals": questions[:10],
            "hook_candidates": hooks,
            "cta_candidates": ctas,
            "content_angle": self._select_content_angle(
                purchase_intent=purchase_intent,
                sentiment=sentiment,
                questions=questions,
            ),
            "evidence": evidence,
            "warnings": self._warnings(
                review_count=len(review_texts),
                social_count=len(social_texts),
                total_count=len(combined),
            ),
        }

    def _normalize_texts(self, source: Any) -> List[str]:
        if source is None:
            return []

        if isinstance(source, str):
            cleaned = self._clean_text(source)
            return [cleaned] if self._valid_text(cleaned) else []

        if isinstance(source, dict):
            for key in (
                "comments",
                "reviews",
                "items",
                "data",
                "results",
                "review_list",
            ):
                value = source.get(key)
                if value:
                    return self._normalize_texts(value)

            text = self._dict_to_text(source)
            return [text] if self._valid_text(text) else []

        if not isinstance(source, (list, tuple, set)):
            return []

        output: List[str] = []
        for item in source:
            if isinstance(item, str):
                text = self._clean_text(item)
            elif isinstance(item, dict):
                text = self._dict_to_text(item)
            else:
                text = ""

            if self._valid_text(text):
                output.append(text)

        return output

    def _dict_to_text(self, item: Dict[str, Any]) -> str:
        values: List[str] = []
        for key in self.TEXT_KEYS:
            value = item.get(key)
            if isinstance(value, str) and value.strip():
                values.append(value.strip())
        return self._clean_text(" ".join(values))

    def _clean_text(self, value: Any) -> str:
        text = str(value or "")
        text = re.sub(r"<[^>]+>", " ", text)
        text = re.sub(r"https?://\S+", " ", text)
        text = re.sub(r"\s+", " ", text)
        return text.strip()

    def _valid_text(self, text: str) -> bool:
        if len(text) < 2 or len(text) > 1500:
            return False
        if re.fullmatch(r"[\W_]+", text, flags=re.UNICODE):
            return False
        return True

    def _deduplicate(self, texts: Sequence[str]) -> List[str]:
        output: List[str] = []
        seen = set()

        for text in texts:
            key = re.sub(
                r"[^0-9a-zA-Z가-힣\u4e00-\u9fff]",
                "",
                text,
            ).lower()

            if not key or key in seen:
                continue

            seen.add(key)
            output.append(text)

        return output

    def _score_rules(
        self,
        texts: Sequence[str],
        rules: Dict[str, Sequence[str]],
    ) -> List[Dict[str, Any]]:
        results: List[Dict[str, Any]] = []

        for label, patterns in rules.items():
            evidence: List[str] = []
            matched_patterns: List[str] = []
            count = 0
            score = 0.0

            for text in texts:
                lowered = text.lower()
                local_matches = [
                    pattern
                    for pattern in patterns
                    if pattern.lower() in lowered
                ]

                if not local_matches:
                    continue

                count += 1
                matched_patterns.extend(local_matches)
                score += 2.0 + len(local_matches) * 0.8

                if len(evidence) < 3:
                    evidence.append(text[:180])

            if count:
                results.append(
                    {
                        "label": label,
                        "score": round(score + count * 0.5, 1),
                        "count": count,
                        "matched_patterns": list(
                            dict.fromkeys(matched_patterns)
                        ),
                        "evidence": evidence,
                    }
                )

        results.sort(
            key=lambda item: (
                item.get("score", 0),
                item.get("count", 0),
            ),
            reverse=True,
        )
        return results

    def _purchase_intent(self, texts: Sequence[str]) -> Dict[str, Any]:
        evidence: List[str] = []
        matched_count = 0
        signal_count = 0

        for text in texts:
            lowered = text.lower()
            matches = [
                word
                for word in self.PURCHASE_WORDS
                if word.lower() in lowered
            ]
            if matches:
                matched_count += 1
                signal_count += len(matches)
                if len(evidence) < 5:
                    evidence.append(text[:180])

        ratio = matched_count / max(1, len(texts))
        score = min(100, round(ratio * 120 + signal_count * 3))

        if score >= 60:
            level = "high"
            label = "구매 의도가 높음"
        elif score >= 30:
            level = "medium"
            label = "구매 관심이 있음"
        else:
            level = "low"
            label = "구매 의도가 아직 낮음"

        return {
            "level": level,
            "label": label,
            "score": score,
            "matched_count": matched_count,
            "ratio": round(ratio, 3),
            "evidence": evidence,
        }

    def _sentiment(self, texts: Sequence[str]) -> Dict[str, Any]:
        positive = 0
        negative = 0
        neutral = 0

        for text in texts:
            lowered = text.lower()
            pos = sum(word.lower() in lowered for word in self.POSITIVE_WORDS)
            neg = sum(word.lower() in lowered for word in self.NEGATIVE_WORDS)

            if pos > neg:
                positive += 1
            elif neg > pos:
                negative += 1
            else:
                neutral += 1

        total = max(1, len(texts))
        return {
            "positive_count": positive,
            "negative_count": negative,
            "neutral_count": neutral,
            "positive_percent": round(positive / total * 100, 1),
            "negative_percent": round(negative / total * 100, 1),
            "neutral_percent": round(neutral / total * 100, 1),
        }

    def _extract_questions(self, texts: Sequence[str]) -> List[Dict[str, Any]]:
        results: List[Dict[str, Any]] = []

        for text in texts:
            lowered = text.lower()
            matches = [
                word
                for word in self.QUESTION_WORDS
                if word.lower() in lowered
            ]
            if matches:
                results.append(
                    {
                        "text": text[:200],
                        "signals": list(dict.fromkeys(matches)),
                    }
                )

        return results

    def _common_keywords(self, texts: Sequence[str]) -> List[Dict[str, Any]]:
        counter: Counter[str] = Counter()

        for text in texts:
            tokens = re.findall(
                r"[가-힣]{2,}|[a-zA-Z]{3,}|\d+[a-zA-Z가-힣]+",
                text.lower(),
            )

            for token in tokens:
                if token in self.STOP_WORDS:
                    continue
                counter[token] += 1

        return [
            {"keyword": word, "count": count}
            for word, count in counter.most_common(20)
        ]

    def _evidence_samples(
        self,
        review_texts: Sequence[str],
        social_texts: Sequence[str],
    ) -> Dict[str, List[str]]:
        return {
            "reviews": [text[:180] for text in review_texts[:5]],
            "social_comments": [text[:180] for text in social_texts[:5]],
        }

    def _build_buy_reason(
        self,
        best_pain: str,
        best_benefit: str,
        purchase_intent: Dict[str, Any],
    ) -> str:
        if purchase_intent.get("level") == "high":
            return f"{best_pain}는 문제를 {best_benefit}는 방식으로 해결하고 싶어서"
        return f"{best_pain}는 문제를 줄이고 {best_benefit}는 장점을 얻기 위해"

    def _build_hooks(
        self,
        product_name: str,
        best_pain: str,
        best_benefit: str,
        purchase_intent: Dict[str, Any],
        questions: Sequence[Dict[str, Any]],
    ) -> List[str]:
        name = product_name.strip() or "이 제품"
        hooks = [
            f"{best_pain}면 {name}, 이렇게 써보세요.",
            f"왜 다들 {name}을 찾는지 직접 확인해봤습니다.",
            f"{best_benefit}는 말, 실제 반응은 어땠을까요?",
        ]

        if purchase_intent.get("level") == "high":
            hooks.insert(
                0,
                f"댓글에서 구매방법을 계속 묻는 {name}, 이유가 있었습니다.",
            )

        if questions:
            hooks.append(
                f"'{questions[0].get('text', '')}' 가장 많이 궁금해한 부분부터 알려드릴게요."
            )

        return list(dict.fromkeys(hooks))[:5]

    def _build_ctas(
        self,
        product_name: str,
        purchase_intent: Dict[str, Any],
    ) -> List[str]:
        name = product_name.strip() or "제품"
        ctas = [
            f"{name} 정보가 궁금하면 댓글에 '정보'를 남겨주세요.",
            "실사용 후기를 더 보고 결정해 보세요.",
            "제품 정보는 프로필 링크에서 확인하세요.",
        ]

        if purchase_intent.get("level") == "high":
            ctas.insert(
                0,
                "구매방법이 궁금하면 댓글에 '구매'를 남겨주세요.",
            )

        return list(dict.fromkeys(ctas))[:4]

    def _select_content_angle(
        self,
        purchase_intent: Dict[str, Any],
        sentiment: Dict[str, Any],
        questions: Sequence[Dict[str, Any]],
    ) -> str:
        if purchase_intent.get("level") == "high":
            return "구매질문 응답형"
        if questions:
            return "궁금증 해결형"
        if sentiment.get("negative_percent", 0) >= 30:
            return "불편→해결형"
        return "실사용 후기형"

    def _warnings(
        self,
        review_count: int,
        social_count: int,
        total_count: int,
    ) -> List[str]:
        warnings: List[str] = []

        if total_count < 5:
            warnings.append("분석 문장이 5개 미만이라 결과 신뢰도가 낮을 수 있습니다.")
        if review_count == 0:
            warnings.append("쿠팡 리뷰가 없어 소셜 댓글 중심으로 분석했습니다.")
        if social_count == 0:
            warnings.append("소셜 댓글이 없어 상품 리뷰 중심으로 분석했습니다.")

        return warnings

    def _best_label(
        self,
        items: Sequence[Dict[str, Any]],
        fallback: str,
    ) -> str:
        if not items:
            return fallback
        return str(items[0].get("label") or fallback)

    def _empty_result(self, product_name: str) -> Dict[str, Any]:
        return {
            "ok": False,
            "version": self.VERSION,
            "product_name": product_name,
            "review_count": 0,
            "social_comment_count": 0,
            "total_text_count": 0,
            "pain_points": [],
            "benefits": [],
            "buy_reasons": [],
            "personas": [],
            "common_keywords": [],
            "best_pain_point": "사용 전 불편함이나 구매 고민이 있다",
            "best_benefit": "사용이 간편하고 생활을 편리하게 만든다",
            "best_buy_reason": "생활 속 불편을 줄이기 위해",
            "purchase_reason": "생활 속 불편을 줄이기 위해",
            "best_persona": "간편하고 실용적인 제품을 찾는 사람",
            "target_customer": "간편하고 실용적인 제품을 찾는 사람",
            "objection": "실제 효과와 사용 편의성을 확인하고 싶다",
            "purchase_intent": {
                "level": "unknown",
                "label": "분석 데이터 없음",
                "score": 0,
                "matched_count": 0,
                "ratio": 0.0,
                "evidence": [],
            },
            "sentiment": {
                "positive_count": 0,
                "negative_count": 0,
                "neutral_count": 0,
                "positive_percent": 0.0,
                "negative_percent": 0.0,
                "neutral_percent": 0.0,
            },
            "question_signals": [],
            "hook_candidates": [],
            "cta_candidates": [],
            "content_angle": "기본 상품 소개형",
            "evidence": {
                "reviews": [],
                "social_comments": [],
            },
            "warnings": ["분석할 리뷰와 소셜 댓글이 없습니다."],
        }
